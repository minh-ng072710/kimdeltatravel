<?php
/**
 * Footer clean template part.
 *
 * @author    Themedelight
 * @package   Themedelight/AdventureTours
 * @version   1.0.0
 */

?>
	</div><!-- .layout-content -->
	<?php wp_footer(); ?>
</body>
</html>
