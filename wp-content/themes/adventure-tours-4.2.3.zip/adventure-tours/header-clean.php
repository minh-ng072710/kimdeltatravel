<?php
/**
 * Header clean template part.
 *
 * @author    Themedelight
 * @package   Themedelight/AdventureTours
 * @version   4.1.5
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
	<div class="layout-content">
