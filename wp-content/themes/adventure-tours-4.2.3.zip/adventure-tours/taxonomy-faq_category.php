<?php
/**
 * Renders FAQ category page.
 *
 * @author    Themedelight
 * @package   Themedelight/AdventureTours
 * @version   1.1.0
 */

get_template_part( 'template-faq' );
