<?php
/**
 * Search result rendering template part.
 *
 * @author    Themedelight
 * @package   Themedelight/AdventureTours
 * @version   1.0.0
 */

// TODO complete search result rendering template part.
?>
<div class="search-result-block padding-left padding-right margin-bottom">
	<h2 class="search-result-block__title"><a href="<?php the_permalink(); ?>" class="search-result-block__link"><?php the_title(); ?></a></h2>
</div>
