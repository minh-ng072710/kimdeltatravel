<?php
/**
 * Tour category template.
 *
 * @author    Themedelight
 * @package   Themedelight/AdventureTours
 * @version   1.0.0
 */

adventure_tours_render_template_part( 'templates/tour/archive' );
